package org.koreait.member;

import lombok.Getter;
import lombok.Setter;

@Setter @Getter
public class Member {
    private long seq; // 회원 번호
    private String email; // 이메일
    private String password;

}
